# Create database
kubectl exec -it -n bootcamp mysql-0 -- sh -c 'mysql -h mysql --password="Shining-Ozone-Ranch4" -e "CREATE DATABASE wordpress"'

# connect to SQL
kubectl exec -it -n bootcamp mysql-0 -- mysql -h mysql --password="Shining-Ozone-Ranch4"