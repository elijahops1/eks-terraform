kubectl apply -f deploy.yml -n bootcamp
kubectl apply -f hpa.yml -n bootcamp
kubectl apply -f service.yml -n bootcamp
#kubectl apply -f pv.yml -n bootcamp
#kubectl apply -f pvc.yml -n bootcamp