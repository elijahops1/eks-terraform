kubectl create ns bootcamp
kubectl apply -f namespace-quota.yml