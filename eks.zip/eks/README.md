# AWS EKS SETUP:

## Initial Installtion Required

- awscli
- eksctl

## Create Cluster

```
cd eks
eksctl create cluster -f cluster.yaml
```

- This command will create all the required resources to setup and sping Kubernetes in AWS

## Things crated by eksctl

- VPC
- Subnets
- SecurityGroup
- NAT Gateway
- Route Gateway
- EC2 Instance
- EBS volume
- All the iam rules required to connect different services to each other
- Check Cloudformation for more..


## Created Manually

- Create EFS manually and connect the VPS , subnet and sg group as shown in picture:
- Location : shots/EFS-Network.png
- All the connection is done by eksctl not other setup is required. 


# Uninstall

- Command to uninstall all the services

```
cd eks
# This command will remove all the resource used in EKS and its peripherial. Note: AWS takes time to delete more then 30min sometimes
eksctl delete cluster -f cluster.yaml
```

# EFS Delete
aws efs delete-file-system --file-system-id fs-0b15d1f9ffaea59fc