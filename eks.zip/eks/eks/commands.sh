#!/bin/bash
# Create EKS Cluster
eksctl create cluster -f cluster.yaml

# For metrics Api
kubectl create -f https://raw.githubusercontent.com/pythianarora/total-practice/master/sample-kubernetes-code/metrics-server.yaml
kubectl top nodes
kubectl top pods