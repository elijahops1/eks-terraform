#!/bin/bash
read -p "Node Group Name : " ngn
read -p "Node Desired : " ds
read -p "Node Min : " nmin
read -p "Node Max : " nmax
if [ -z $ds ] || [ -z $nmin ] || [ -z $nmax ]
then
	echo "Enter Variables Correctly"
else
	eksctl scale nodegroup --cluster=bootcamp --nodes=$ds --name=$ngn --nodes-min=$nmin --nodes-max=$nmax
fi