helm repo add bitnami https://charts.bitnami.com/bitnami
helm upgrade --install wordpress bitnami/wordpress --version 17.0.4 -f values.yml -n bootcamp

# Remove
#helm uninstall wordpress bitnami/wordpress -n bootcamp